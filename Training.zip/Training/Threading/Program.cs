﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Threading
{
    class Program
    {
        static void Main(string[] args)
        {
            Program pr = new Program();
            Thread tr = new Thread(new ThreadStart(pr.loop));
            tr.Start();
            bool val = tr.IsBackground;
            bool val2 = tr.IsAlive;
            ThreadPriority trp = tr.Priority;
            Console.WriteLine(val);
            Console.WriteLine(val2);
            Console.WriteLine(trp);
            tr.Priority = ThreadPriority.Highest;
            ThreadPriority trp1 = tr.Priority;
            Console.WriteLine(trp1);
            Console.WriteLine(tr.ThreadState);
        }
        public void loop()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Simple thread: " + i);
                if(i==5)
                {
                    Thread.Sleep(4000);
                }
            }
        }
    }
}
