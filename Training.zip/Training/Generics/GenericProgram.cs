﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    class GenericProgram
    {
        static void Main(string[] args)
        {
            //Gencls<int> obj1 = new Gencls<int>(10);
            //Gencls<double> obj2 = new Gencls<double>(20.10);
            //Console.WriteLine(obj1.disp(25));
            //Console.WriteLine(obj2.disp(45.5));

            //Gencoll coll = new Gencoll();
            Gencoll.list();
            Gencoll.dictcoll();
        }
    }
}
