﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    interface IInterface1
    {

    }
    //class Gencls <T> where T : ITnterface1
    //generic class
    class Gencls<T> where T : new()
    {
        //generic field
        private T genval;

        //generic constructor
        public Gencls(T val)
        {
            genval = val;
        }

        //generic method
        public T disp(T age)
        {
            Console.WriteLine("Your age is: " + age);
            Console.WriteLine("Parameter type: " + typeof(T).ToString() + "Value: " + age);
            Console.WriteLine("Parameter type: " + typeof(T).ToString() + "Value: " + genval);
            return genval;
        }


    }
}
