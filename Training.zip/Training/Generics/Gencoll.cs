﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    class Movie
    {
        string movname;
        int movid;
    }
    class Gencoll
    {
        public static void list()
        {
            //Also called object initializer
            List<int> list1 = new List<int>
            {
                10,
                20,
                30,
                40
            };

            for (int i = 0; i < list1.Count; i++)
            {
                Console.WriteLine("List of values: " + list1[i]);
            }

        }

        public static void dictcoll()
        {
            Dictionary<int, string> dobj = new Dictionary<int, string>
            {
                //mid, moviename, to call movie class and access movie name and id, add values based on the object of movie class
                {1,"Frozen"},
                {2,"Tangled"},
                {3,"Mulan"},
            };

            foreach (KeyValuePair<int,string> item in dobj)
            {
                Console.WriteLine("Dictionary Object Items: " + item.Key + " -> " + item.Value);
            }
        }
    }
}
