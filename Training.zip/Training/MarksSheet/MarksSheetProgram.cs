﻿using System;
class Marks
{
    static void Main()
    {
        string[] input;
        string[] testOne = new string[40];
        string[] testTwo = new string[40];
        int count = 0;

        Console.WriteLine("You are to enter two test marks per student.");
        Console.WriteLine("Enter the letter e to end");

        for (int i = 0; i <= 40; i++)
        {
            Console.Write("Enter marks for student " + (i + 1) + ": ");
            input = Console.ReadLine().Split(',');

            if (input[0] == "e") break;
            else if (input[0] != "e")
            {
                testOne[i] = input[0];
                testTwo[i] = input[1];
            }
            count++;
        }

        Console.WriteLine("\nStudent  Maths   English   Total");
        Console.WriteLine("=======  ======   ======   =====");
        for (int i = 1; i <= count; i++)
        {
            Console.WriteLine(i + " " + testOne[i] + " " + testTwo[i]);
        }
    }
}