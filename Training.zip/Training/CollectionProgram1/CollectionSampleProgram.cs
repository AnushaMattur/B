﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _17ArrList
{
    public class Movie
    {
        public String movieName { get; set; }
        public String movieStar { get; set; }
        public String genre { get; set; }
        public String review { get; set; }
        public int collection { get; set; }
        public int ratings { get; set; }
    }

    public class MovieMain
    {
            public static void Main(string[] args)
            {
                Console.WriteLine("Welcome");
                //int input = Convert.ToInt32(Console.ReadLine());
                ArrayList Movies = new ArrayList();

                Movie refmovie = new Movie();
                refmovie.movieName = "Rajkumar";
                refmovie.movieStar = "Puneet Rajkumar";
                refmovie.genre = "Action";
                refmovie.review = "Amazing";
                refmovie.collection = 2000000;
                refmovie.ratings = 4;
                Movies.Add(refmovie);

                Movie refmovie1 = new Movie();
                refmovie.movieName = "Mungarumale";
                refmovie.movieStar = "Ganesh";
                refmovie.genre = "Romantic";
                refmovie.review = "Good";
                refmovie.collection = 2750000;
                refmovie.ratings = 4;
                Movies.Add(refmovie1);

                Console.WriteLine("Add new details about movies: ");
                Console.WriteLine("Enter number of movies to add: ");
                int countMovies = Convert.ToInt32(Console.ReadLine());

                for (int i = 0; i < countMovies; i++)
                {
                    Movie newMovies = new Movie();
                    Console.WriteLine("Enter details about movie: " + (i + 1));
                    Console.WriteLine("Enter movie name: ");
                    newMovies.movieName = Console.ReadLine();
                    Console.WriteLine("Enter the name of the star: ");
                    newMovies.movieStar = Console.ReadLine();
                    Console.WriteLine("Genre: ");
                    newMovies.genre = Console.ReadLine();
                    Console.WriteLine("Review: ");
                    newMovies.review = Console.ReadLine();
                    Console.WriteLine("Enter the box office collection: ");
                    newMovies.collection = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the ratings: ");
                    newMovies.ratings = Convert.ToInt32(Console.ReadLine());
                    Movies.Add(newMovies);
               
                    Console.WriteLine("MOVIE DETAILS");
                    foreach (var item in Movies)
                    {
                        Console.WriteLine(newMovies.movieName + " " + newMovies.movieStar + " " + newMovies.genre + " " + newMovies.review + " " + newMovies.collection + " " + newMovies.ratings);
                    } 
                    
                    if(newMovies.ratings < 3)
                    {
                        Movies.Remove(newMovies);
                    }

                    foreach (var item in Movies)
                    {
                        Console.WriteLine(newMovies.movieName + " " + newMovies.movieStar + " " + newMovies.genre + " " + newMovies.review + " " + newMovies.collection + " " + newMovies.ratings);
                    }
                }
                Console.ReadLine();
            }
        }
}