﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] arr = new int[2,3];
            for(int i=0;i<2;i++)
            {
                Console.WriteLine();
                for(int j=0;j<3;j++)
                {

                }
            }
        }
    }
}
