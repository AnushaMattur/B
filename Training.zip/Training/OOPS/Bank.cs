﻿using System;

namespace Bank
{
    public class InsufficientBalanceException : Exception
    {
        public string msg;
        public InsufficientBalanceException()
        {

        }
        public InsufficientBalanceException(String msg)
        {
            this.msg = msg;
        }
        public string GetMessage()
        {
            return this.msg;
        }
    }
    public class BankClass
    {
        int balance = 1000;
        int pin = 0909;
        public void Credit()
        {
            Console.WriteLine("Enter your pin to continue");
            int entered_pin = Convert.ToInt32(Console.ReadLine());
            if (entered_pin == pin)
            {
                Console.WriteLine("Enter the amount to be credited");
                int credit_amount = Convert.ToInt32(Console.ReadLine());
                balance += credit_amount;
                Console.WriteLine("Balance amount is " + balance);
            }
            else
            {
                //Console.Beep();
                Console.WriteLine("You have entered an incorrect pin number");
            }
        }

        public void Withdraw()
        {
            Console.WriteLine("Enter the amount to be withdrawn");
            int withdraw_amount = Convert.ToInt32(Console.ReadLine());
            try
            {
                Console.WriteLine("Enter your pin to continue");
                int entered_pin = Convert.ToInt32(Console.ReadLine());
                if (entered_pin == pin)
                {
                    if (withdraw_amount > balance - 1000)
                    {
                        Console.WriteLine("Minimum balance should be 1000, so withdrawal not possible");
                        throw new InsufficientBalanceException("Insufficient Balance");
                    }
                    else
                    {
                        Console.WriteLine("Withdrawal successful");
                        balance -= withdraw_amount;
                    }
                }
                else
                {
                    Console.WriteLine("You have entered an incorrect pin number");
                }
            }
            catch (InsufficientBalanceException ex)
            {
                Console.WriteLine(ex.GetMessage());
            }
        }

        public void Balance()
        {
            Console.WriteLine("Enter your pin to continue");
            int entered_pin = Convert.ToInt32(Console.ReadLine());
            if (entered_pin == pin)
            {
                Console.WriteLine("Your balance is: " + balance);
            }
            else
            {
                Console.WriteLine("You have entered an incorrect pin number");
            }
        }
    }
    public class MainProgram
    {
        public static void Main()
        {
            BankClass refbankclass = new BankClass();
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Welcome to Broadridge bank \n");
            Console.ResetColor();
            while (true)
            {
                Console.WriteLine("Enter 1 to Credit \n Enter 2 to Withdraw \n Enter 3 to Check balance \n Enter 4 to exit ");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        refbankclass.Credit();
                        break;

                    case 2:
                        refbankclass.Withdraw();
                        break;

                    case 3:
                        refbankclass.Balance();
                        break;
                    case 4: Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid entry");
                        break;
                }
            }
        }
    }
}