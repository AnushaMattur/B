﻿//s
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace student
{
    class StudentMarksList
    {
        public string name;
        public int[] marks = new int[5];
        public int total;
    }
    class Students
    {
        public List<StudentMarksList> m_studList = new List<StudentMarksList>();
        public int m_nMaxStudents;
        public int AddRecord(string name, int[] marks)
        {
            StudentMarksList stud = new StudentMarksList();
            stud.name = name;        
            stud.marks = marks;
            stud.total = 0;
            for (int i = 0; i < 5; i++)
                stud.total += stud.marks[i];
            m_studList.Add(stud);
            m_nMaxStudents = m_studList.Count;
            if (stud.total > 70)
            {
                Console.WriteLine("Destinction");
            }
            else if (stud.total > 60)
            {
            }
            return 1;
        }
    }

    class Program
    {
        static public Students theStudents = new Students();
        static public void ViewRecords()
        {
            Console.WriteLine("_______________________________________________________________________________");
            Console.WriteLine("SNo Student Name       Sub1   Sub2   Sub3   Sub4   Sub5   Total      Grade");        
            Console.WriteLine("_______________________________________________________________________________");
            for (int i = 0; i < theStudents.m_nMaxStudents; i++)
            {
                Console.Write("{0, -5}", i + 1);
                Console.Write("{0, -19}", theStudents.m_studList[i].name);
                Console.Write("{0, -7}", theStudents.m_studList[i].marks[0]);
                Console.Write("{0, -7}", theStudents.m_studList[i].marks[1]);
                Console.Write("{0, -7}", theStudents.m_studList[i].marks[2]);
                Console.Write("{0, -7}", theStudents.m_studList[i].marks[3]);
                Console.Write("{0, -7}", theStudents.m_studList[i].marks[4]);
                Console.Write("{0, -7}", theStudents.m_studList[i].total);
                if ((theStudents.m_studList[i].total / 5) > 70)
                {
                    Console.Write("Destinction");
                }
                else if ((theStudents.m_studList[i].total / 5) > 60)
                {
                    Console.Write("First Class");
                }
                else if ((theStudents.m_studList[i].total / 5) > 50)
                {
                    Console.Write("Second Class");
                }
                else
                {
                    Console.Write("   Fail");
                }
                Console.WriteLine();
            }
            Console.WriteLine("_______________________________________________________________________________");
            int large = 0;
            for (int i = 0; i < theStudents.m_nMaxStudents; i++)
            {
                if (theStudents.m_studList[i].total > large)
                    large = theStudents.m_studList[i].total;
            }
            Console.WriteLine("Highest marks obtained is " + large);
        }

        static public void InputRecords()
        {
            Console.Write("Student Name: ");
            string name;
            int[] marks = new int[5];
            name = Console.ReadLine();        
            for (int i = 1; i <= 5; i++)
            {
            l2: Console.Write("Sub " + i.ToString() + " Mark: ");
                try
                {
                    marks[i - 1] = Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception)
                {
                    Console.WriteLine("Please enter the accurate values");
                    goto l2;
                }
            }
            theStudents.AddRecord(name, marks);
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Student's MarkList");
            Console.Write("Enter the number of students: ");
            int numStudents = -1;
        l1: string s = Console.ReadLine();
            try
            {
                numStudents = Convert.ToInt32(s);
            }
            catch (Exception)
            {
                Console.WriteLine("Please enter the accurate details");
                goto l1;
            }
            for (int i = 1; i <= numStudents; i++)
            {
                Console.WriteLine("\nEnter " + i.ToString() + " Student Information\n");
                InputRecords();
            }
            ViewRecords();
            char ch = Console.ReadKey().KeyChar;
        }
    }
}