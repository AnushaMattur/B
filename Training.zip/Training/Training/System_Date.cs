﻿using System;

class Program
{
    static void Main()
    {
        DateTime now = DateTime.Now;
        Console.WriteLine(now);
        String date = now.ToString("D");
        Console.WriteLine(date);
        DateTime dt = new DateTime();
        Console.WriteLine(dt.Date);
        Console.ReadKey();
    }
}