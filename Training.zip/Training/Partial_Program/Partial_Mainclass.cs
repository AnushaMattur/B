﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Partial_Program
{   
    class Partial_Mainclass
    {
        static void Main(string[] args)
        {
            Partial_Demo1 par = new Partial_Demo1();
            Console.ReadKey();     
        }
    }
}
