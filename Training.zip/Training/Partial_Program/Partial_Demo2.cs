﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Partial_Program
{
    public partial class Partial_Demo1
    {
        partial void show2()
        {
            Console.WriteLine("partial method");
        }
        public Partial_Demo1()
        {
            show();
            show2();
        }
    }
}
