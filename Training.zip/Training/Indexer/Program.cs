﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Indexer
{
    class Program
    {
        private string[] list = new string[size];
        static public int size = 10;
        public void OverIndex()
        {
            for(int i = 0; i< size;i++)
            {

            }
        }
        static void Main(string[] args)
        {

        }
    }
}
