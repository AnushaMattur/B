﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedArray
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] flowers = { "Rose", "Tulips", "Daises", "Orchids" };
            Console.WriteLine(flowers.GetLowerBound(0));
            Console.WriteLine(flowers.Rank);
            for(int i=0;i<flowers.Length;i++)
            {
                Console.WriteLine($"Flowers {i + 1} is: {flowers[i]}");
            }

            Array.Reverse(flowers);

            for (int i = 0; i < flowers.Length; i++)
            {
                Console.WriteLine($"Flowers {i + 1} is: {flowers[i]}");
            }

            //2-D
            int[,] numdim = { { 10, 20 }, { 30, 40 }, { 50, 60 } };
            int d1 = numdim.GetLength(0);
            int d2 = numdim.GetLength(1);

            Console.WriteLine("Dimension1: " + d1 + " Dimension2: " + d2);

            for (int i = 0; i < d1; i++)
            {
                for (int j = 0; j < d2; j++)
                {
                    Console.Write(numdim[i,j] + " ");
                }
                Console.WriteLine();
            }

            //Jagged array
            int[][] jdarr1 = new int[3][];
            jdarr1[0] = new int[4];
            jdarr1[1] = new int[2];
            jdarr1[2] = new int[3];
            jdarr1[0] = new int[] { 2, 4, 6, 8 };
            jdarr1[1] = new int[] { 1,3,5 };
            jdarr1[2] = new int[] { 2, 4, 6 };

            //jagged array shortcut
            int[][] jdarr2 =
            {
                new int[] {1,2,3},
                new int[] {2,4},
                new int[] {3,5,7,9}
            };

            for(int i=0;i<jdarr2.Length;i++)
            {
                System.Console.Write("Element{0}: ", i + 1);

                for(int j=0;j<jdarr2[i].Length;j++)
                {
                    System.Console.Write($"{jdarr2[i][j]}"+ " ");
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
