﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _17ArrList
{
    public class Movie
    {
        public String movieName { get; set; }
        public String movieStar { get; set; }
        public String genre { get; set; }
        public String review { get; set; }
        public int collection { get; set; }
        public int ratings { get; set; }
    }

    public class MovieMain
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Welcome");
            ArrayList Movies = new ArrayList();

            Movie refmovie = new Movie();

            refmovie.movieName = "Rajkumar";
            refmovie.movieStar = "Puneet Rajkumar";
            refmovie.genre = "Action";
            refmovie.review = "Amazing";
            refmovie.collection = 2000000;
            refmovie.ratings = 4;
            Movies.Add(refmovie);

            refmovie.movieName = "Mungarumale";
            refmovie.movieStar = "Ganesh";
            refmovie.genre = "Romantic";
            refmovie.review = "Good";
            refmovie.collection = 2750000;
            refmovie.ratings = 4;
            Movies.Add(refmovie);

            Console.WriteLine("Add new details about movies: ");
            Console.Write("Enter number of movies to add: ");
            int countMovies = Convert.ToInt32(Console.ReadLine());         
            for (int i = 0; i < countMovies; i++)
            {
                Console.WriteLine("Enter details about movie: " + (i + 1));
                Console.Write("Enter movie name: ");
                refmovie.movieName = Console.ReadLine();
                Console.Write("Enter the name of the star: ");
                refmovie.movieStar = Console.ReadLine();
                Console.Write("Genre: ");
                refmovie.genre = Console.ReadLine();
                Console.Write("Review: ");
                refmovie.review = Console.ReadLine();
                Console.Write("Enter the box office collection: ");
                refmovie.collection = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter the ratings: ");
                refmovie.ratings = Convert.ToInt32(Console.ReadLine());
                Movies.Add(refmovie);
            }

            Console.WriteLine("MOVIE DETAILS");
            foreach (Movie item in Movies)
            {
                Console.WriteLine(item.movieName + " " + item.movieStar + " " + item.genre + " " + item.review + " " + item.collection + " " + item.ratings);
            }

            if (refmovie.ratings < 3)
            {
                Movies.Remove(refmovie);
            }

            Console.WriteLine("UPDATED MOVIE DETAILS");
            foreach (Movie item in Movies)
            {
                Console.WriteLine(item.movieName + " " + item.movieStar + " " + item.genre + " " + item.review + " " + item.collection + " " + item.ratings);
            }
            Console.ReadLine();
        }      
    }
}