﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Reflection
{
    class ReflectionProgram
    {
            static void Main(string[] args)
            {
                Movies m1 = new Movies();
                m1.ActorID = 1;
                m1.ActorName = "Prabhas";

                Type typ = typeof(Movies);
                //To know the info about properties
                foreach (PropertyInfo pr in typ.GetProperties())
                {
                    //It will gicve the name of the property
                    string name = pr.Name;
                    //What are you storing in the property
                    object val = pr.GetValue(m1, null);

                    if (val is int)
                    {
                        Console.WriteLine("It's an integer: " + name + " " + val);
                    }
                    else
                    {
                        if (val is string)
                        {
                            Console.WriteLine("Its string: " + name + " " + val);
                        }
                    }
                }

                //to know the info about the method
                foreach (MethodInfo pr in typ.GetMethods())
                {
                    //it will gicve the name of the property
                    string name = pr.Name;
                    //what are you storing in the property
                    //object val = pr.getvalue(m1, null);

                    //if (val is int)
                    //{
                    //    Console.WriteLine("it's an integer: " + name + " " + val);
                    //}
                    //else
                    //{
                    //    if (val is string)
                    //    {
                    //        Console.WriteLine("its string: " + name + " " + val);
                    //    }
                    //}
                }
        }

        public static void assemblyload()
            {
                Assembly asmbly = Assembly.GetExecutingAssembly();
                Type[] asmtypes = asmbly.GetTypes();
                foreach (Type t in asmtypes)
                {
                    Console.WriteLine(t.Name + " " + t.AssemblyQualifiedName + " " + t.BaseType);
                }
                Console.ReadKey();
            }
        }
        interface IInterface
        {

        }

        class Myclass
        {

        }

        class Movies
        {
            private string _actorname;
            public void show()
            {
                Console.WriteLine("Show time!!");
            }
            public Movies()
            {
                Console.WriteLine("Constructor");
            }
            public int ActorID { get; set; }
            public string ActorName
            {
                get
                {
                    return _actorname;
                }

                set
                {
                    _actorname = value;
                }
            }
        }
    }
