﻿//HOTEL BOOKING

using System;

namespace HotelBooking
{
    class HotelBooking
    {
        public static void Main(string[] args)
        {
            try
            {
                //int flag = 0;
                int numberofweekends = 0, numberofweekdays = 0, specialday = 0, total_cost = 0;
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("WELCOME");
                Console.ResetColor();
                Console.WriteLine("Enter a valid name");
                string customername = Console.ReadLine();
                Console.WriteLine("\nHi " + customername + "!");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("INFO");
                Console.WriteLine("Monday to Thursay: 6000 per day");
                Console.WriteLine("Friday to Sunday: 8000 per day");
                Console.WriteLine("On New Year's Eve or Christmas eve: 12000 per day");
                Console.ResetColor();
                Console.WriteLine("Enter the checkin date in the format mm/dd/yyyy");
                label1: DateTime checkIn = Convert.ToDateTime(Console.ReadLine());
                        if(checkIn <= DateTime.Now)
                        {
                            Console.WriteLine("Invalid date, please enter a valid date in the format mm/dd/yyyy");
                            goto label1;
                        }
                        DayOfWeek checkInDay = checkIn.DayOfWeek;
                Console.WriteLine("Enter the checkout date in the format mm/dd/yyyy");
                label2: DateTime checkOut = Convert.ToDateTime(Console.ReadLine());
                        DayOfWeek checkOutDay = checkOut.DayOfWeek;
                        if (checkOut <= DateTime.Now)
                        {
                            Console.WriteLine("Invalid date, please enter a valid date in the format mm/dd/yyyy");
                            goto label2;
                        }
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("\nBILL");
                Console.ResetColor();
                Console.WriteLine("Checkin day: " + checkIn.ToString("dd/MM/yyyy") + "," + checkInDay + "\nCheckout day: " + checkOut.ToString("dd/MM/yyyy") + "," + checkOutDay);
                TimeSpan timespan = checkOut - checkIn;
                Double numberofdays = timespan.TotalDays;
                Console.WriteLine("Total number of days: " + numberofdays);

                DateTime i = checkIn;

                while (i < checkOut)
                {
                    if ((i.Day == 25 && i.Month == 12) || (i.Day == 31 && i.Month == 12) || (i.Day == 1 && i.Month == 1))
                    {
                        specialday++;
                    }
                    else if (i.DayOfWeek == DayOfWeek.Friday || i.DayOfWeek == DayOfWeek.Saturday || i.DayOfWeek == DayOfWeek.Sunday)
                    {
                        numberofweekends++;
                    }
                    else
                    {
                        numberofweekdays++;
                    }
                    i = i.AddDays(1);
                }
                Console.WriteLine("SpecialDays:" + specialday + " Weekends:" + numberofweekends + " Weekdays:" + numberofweekdays);
                total_cost = (numberofweekdays * 6000) + (numberofweekends * 8000) + (specialday * 12000);
                Console.WriteLine("Sub-Total: " + total_cost);
                Console.WriteLine("Tax rate: 18%");
                Double tax = total_cost * 0.18;
                Console.WriteLine("Tax: " + tax);
                Double totalBill = total_cost + tax;
                Console.WriteLine("Total Amount: " + totalBill);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("THANK YOU!");
                Console.ResetColor();
            }
            catch(Exception e)
            {
                Console.WriteLine("EXCEPTION OCCURED: " + e.Message);
            }
            Console.ReadLine();
        }
    }
}