﻿using System;
using System.Collections.Generic;

namespace student
{
    class StudentMarksList
    {
        public string name;
        public int[] marks = new int[5];
        public int total;
    }
    class Students
    {
        public List<StudentMarksList> mstudList = new List<StudentMarksList>();
        public int m_nMaxStudents;
        public int AddRecord(string name, int[] marks)
        {
            StudentMarksList stud = new StudentMarksList();
            stud.name = name;
            stud.marks = marks;        
            stud.total = 0;
            for (int i = 0; i < 5; i++)                
                stud.total += stud.marks[i];
            mstudList.Add(stud);
            m_nMaxStudents = mstudList.Count;          
            return 1;
        }
    }
    class Program
    {
        static public Students refStudents = new Students();
        static public void ViewRecords()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            Console.ResetColor();           
            Console.WriteLine("StudentNo StudentName      Physics   Chemistry   Mathematics   Biology   English       Total      Grade");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            Console.ResetColor();
            for (int i = 0; i < refStudents.m_nMaxStudents; i++)
            {
                Console.Write("{0, -5}", i + 1);
                Console.Write("{0, -8}", refStudents.mstudList[i].name);
                Console.Write("{0, -8}", refStudents.mstudList[i].marks[0]);
                Console.Write("{0, -8}", refStudents.mstudList[i].marks[1]);
                Console.Write("{0, -8}", refStudents.mstudList[i].marks[2]);
                Console.Write("{0, -8}", refStudents.mstudList[i].marks[3]);
                Console.Write("{0, -8}", refStudents.mstudList[i].marks[4]);
                Console.Write("{0, -8}", refStudents.mstudList[i].total);
                if ((refStudents.mstudList[i].total / 5) > 90)
                {
                    Console.Write("S grade  Distinction");
                }
                else if ((refStudents.mstudList[i].total / 5) > 75)
                {
                    Console.Write("A grade  First Class");
                }
                else if ((refStudents.mstudList[i].total / 5) > 60)
                {
                    Console.Write("B grade  Second Class");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("F grade   Fail");
                    Console.ResetColor();
                }
                Console.WriteLine();
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("-------------------------------------------------------------------------------------------------------");
            Console.ResetColor();
            int large = 0;
            for (int i = 0; i < refStudents.m_nMaxStudents; i++)
            {
                if (refStudents.mstudList[i].total > large)
                    large = refStudents.mstudList[i].total;
            }
            Console.WriteLine("Highest marks obtained is " + large);
        }

        static public void InputRecords()
        {
            Console.Write("Student Id/Name: ");
            string name;
            int[] marks = new int[5];
            name = Console.ReadLine();
            Console.WriteLine("Enter the marks of these below subjects\n1.Physics \n2.Chemistry \n3.Mathematics \n4.Biology \n5.English");
            for (int i = 1; i <= 5; i++)
            {
                l2: Console.Write("Subject " + i + " Mark: ");
                    try
                    {                       
                        int mark = Convert.ToInt32(Console.ReadLine());
                        if (mark < 100)
                        {
                            marks[i - 1] = mark;
                        }
                        else
                        {
                            Console.WriteLine("Enter the correct marks");
                            goto l2;
                        }
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Please enter the correct values");
                        goto l2;
                    }
            }
            refStudents.AddRecord(name, marks);        
        }

        public static void Main(string[] args)
        {
                Console.WriteLine("Student's MarkList");
            l1: Console.Write("Enter the number of students: ");
                int numStudents = -1;
                string s = Console.ReadLine();
                try
                {
                    numStudents = Convert.ToInt32(s);
                }
                catch (Exception)
                {
                    Console.WriteLine("Please give a correct input");
                    goto l1;
                }
                for (int i = 1; i <= numStudents; i++)
                {
                    Console.WriteLine("\nEnter " + i + " Student Information\n");
                    InputRecords();
                }
                ViewRecords();
                char ch = Console.ReadKey().KeyChar;
        }
    }
}

