﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoIdxr;

namespace Indxr
{
    class OverIndex
    {
        public static void Main(string[] args)
        {
            IteratorDemo itr = new IteratorDemo();
            Console.WriteLine("Using a Get Enumerator..");

            //invocation of default enumerator
            foreach (string item in itr)
            {
                Console.WriteLine(item);
            }

            //invoke the named iterator == GetRatings()
            foreach (var item in itr.GetRatings())
            {
                Console.WriteLine(item);
            }            
        }
    }
}
