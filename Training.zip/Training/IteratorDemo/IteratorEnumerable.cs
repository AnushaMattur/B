﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoIdxr
{
    public class IteratorDemo : IEnumerable
    {
        string[] movnames = { "Avatar", "Madmax", "Xmen", "Inception" };
        int[] rating = { 1, 2, 3, 4, 5 };

        //Default Iterator
        public IEnumerator GetEnumerator()
        {
            for (int i = 0; i < movnames.Length; i++)
            {
                yield return movnames[i];
            }
        }

        //Named Iterator
        public IEnumerable GetRatings()
        {
            for (int i = 0; i < rating.Length; i++)
            {
                yield return rating[i];
            }
        }
    }
}
