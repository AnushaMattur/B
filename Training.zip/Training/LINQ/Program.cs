﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            LinqObj();
            Linqoper();
            linqconvert();
        }

        public static void LinqObj()
        {
            int i = 0;
            List<string> movlist = new List<string> { "Pirates of the caribean", "Sanju", "AntMan" ,"Lucy"};
            //Linq
            IEnumerable<string> mov =
                //m is range value
                   from m in movlist
                   where m.Length > 5
                   orderby m descending
                   select m;

            movlist.Add("HarryPotter");

            //It will only create the sql query, it wont execute, after you're trying to access, query will be executed.(Deffered execution)
            foreach(var item in mov)
            {
                i++;
                Console.WriteLine("Movie "+ i +"=" +item);
            }
        }

        public static void Linqoper()
        {
            int i = 0;
            ArrayList list = new ArrayList();
            list.Add("John Travolta");
            list.Add(23);
            list.Add(new Object());
            list.Add("Morgan Freeman");


            var actorname = from name in list.OfType<string>()
                            select name;
            foreach (var item in actorname)
            {
                i++;
                Console.WriteLine("Actor " + i + "=" + item);
            }

            string[] names = { "Bob", "Drew", "Dustin", "Brad", "Alan", "Alpacino" };

            //First it will arrange in alphabetical order and then arrange based on the length
            var query =
                names.OrderBy(n => n)
                .ThenBy(n => n.Length);

            int j = 0;
            foreach (var item in query)
            {
                j++;
                Console.WriteLine("Actor " + j + "=" + item);
            }
        }

        public static void linqconvert()
        {
            //Object initializer
            var employees = new List<Employee>
            {
                new Employee { ID =1, Name = "Maya", DepartmentID = 1 },
                new Employee { ID =2, Name = "Mithran", DepartmentID = 1 },
                new Employee { ID =3, Name = "Mehna", DepartmentID = 2 }
            };

            Dictionary<int, string> empDict = employees.ToDictionary(e => e.ID, e => e.Name);

            foreach (var item in empDict)
            {
                Console.WriteLine("EmpID " + "=" + item.Key);
                Console.WriteLine("Emp Name =>" + item.Value);
            }
        }

        //public static void linqSet()
        //{
        //    //intersect,Except,Union,Union,GroupBy(n=>n%2);
        //    int[] a = { 2, 4, 6, 8, 10, 12 };
        //    int[] b = { 3, 6, 9, 12, 15, 18, 21, 24 };
        //}
    }
}
