﻿using System;

namespace String
{
    public class MainClass
    {
        public static void Main(string[] args)
        {
            string inputline = "I stay in Bangalore";
            string reversedstring = null;
            Console.WriteLine("Enter the string");
            string input = Console.ReadLine();
            char[] reversed_array = input.ToCharArray();
            for(int i = reversed_array.Length - 1; i>=0;i--)
            {
                reversedstring = reversedstring + reversed_array[i];
            }
            Console.WriteLine("Resversed string is: " + reversedstring);

            if(input == reversedstring)
            {
                Console.WriteLine("It is a palindrome");
            }
            else
            {
                Console.WriteLine("It is not a palindrome");
            }

            Console.WriteLine("The total number of characters in the string entered is: " + input.Length);

            Console.WriteLine("The string entered in upper case: " + input.ToUpper());

            Console.WriteLine("The string entered in lower case: " + input.ToLower());

            Console.WriteLine("String with spaces: " + inputline);
            string inputline_withoutspaces = inputline.Replace(" ", "");
            Console.WriteLine("String without spaces: " + inputline_withoutspaces);
            Console.ReadKey();
        }
    }
}
