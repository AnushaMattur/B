﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionProgram
{
    class CollectionProgram
    {
        static void Main(string[] args)
        {
            arrlist();
            HtList();
            SlDemo();
            Console.ReadLine();
        }
        public static void arrlist()
        {
            ArrayList al = new ArrayList();
            al.Add("Sanju");
            al.Add("Gajini");
            al.Add(200);
            al.Add(32.50);
            al.Add(new CollectionProgram());
            foreach(var item in al)
            {
                Console.WriteLine(item);
            }

            al.Remove(200);

            foreach (var item in al)
            {
                Console.WriteLine(item);
            }
        }

        public static void HtList()
        {
            Hashtable ht = new Hashtable();
            ht.Add("M1", "Avatar");
            ht.Add("M2", "Inception");
            ht.Add("M3", "KirikParty");
            ht.Add("M4", "PK");
            //ht.Add("M1","zfvg");

            ICollection k = ht.Keys;
            Console.WriteLine("Movies by Hash table");
            
            foreach(var item in k)
            {
                Console.WriteLine(item + "->" + ht[item]);
            }
            Console.WriteLine();

            //Dictionary
            Console.WriteLine("Hash table using Dictionary");
            foreach(DictionaryEntry de in ht)
            {
                Console.WriteLine($"Key : {de.Key},Value:{de.Value}");
            }
        }

        public static void SlDemo()
        {
            SortedList ht = new SortedList();
            ht.Add("50", "Zootopia");
            ht.Add("40", "Frozen");
            ht.Add("30", "Tangled");
            ht.Add("10", "Moana");

            ICollection k = ht.Keys;
            Console.WriteLine("Movies by SL");

            foreach (var item in k)
            {
                Console.WriteLine(item + "->" + ht[item]);
            }

            //using index
            Console.WriteLine();
            Console.WriteLine("SL using index");
            for(int i=0;i<ht.Count;i++)
            {
                Console.WriteLine($"{ht.GetKey(i),10}{ht.GetByIndex(i),15}");
            }
        }
    }
}
