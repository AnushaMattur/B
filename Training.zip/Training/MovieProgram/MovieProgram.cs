﻿/*
9.	Create a Movie class with movie name, star, release date, id, review(), accept() disp functions. Use property accessors. 
Derive from Movie and create child classes – Hollywood, Indian Movies ->  Bollywood, Kollywood,Tollywood..etc. 
Implement multi-level inheritance, constructors, properties, access specifiers, overloaded, functions/constructors- return types, virtual, override.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieProgram
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the movie world");
            Console.WriteLine("Your ID number is 4532, please do enter this number when it is asked");
            Movie refmovie = new Movie();
            Console.WriteLine("Enter your id number");            
            refmovie.Id = Convert.ToInt32(Console.ReadLine());
            while (true)
            {
                Console.WriteLine("Enter 1 for Hollywood \n Enter 2 for Sandalwood \n Enter 3 for Bollywood \n Enter 4 to exit");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Welcome to Hollywood");
                        break;
                    case 2:
                        Console.WriteLine("Welcome to Sandalwood");
                        break;
                    case 3:
                        Console.WriteLine("Welcome to Bollywood");
                        break;
                    case 4: Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid input");
                        break;
                }
            }
        }
    }
    class Movie
    {
        private int id;
        public int Id { get; set; }
        public String movieName, star, releaseDate;
        
        public void Hello()
        {
            Console.WriteLine("Hi");
        }
        public virtual void Review()
        {            
        }
        public virtual void Accept()
        {
        }
        public virtual void Display()
        {
        }
    }
    class Hollywood : Movie
    {
        Hollywood()
        {
            Console.WriteLine("Hello");
        }
        public override void Review()
        {
            Console.WriteLine("Please describe the movie in a word");
            Console.WriteLine(Console.ReadLine());
        }
        public override void Accept()
        {
            
            Console.WriteLine("Enter a movie name");
            movieName = Console.ReadLine();
            Console.WriteLine("Enter the actors/actress name");
            star = Console.ReadLine();
        }
        public override void Display()
        {
            Console.WriteLine(movieName);
            Console.WriteLine(star);
        }
    }
    class Sandalwood : Movie
    {
        //Sandalwood()
        //{
        //    Console.WriteLine("Hello");
        //}
        public override void Review()
        {
            Console.WriteLine("Please describe the movie in a word");
            Console.WriteLine(Console.ReadLine());
        }
        public override void Accept()
        {
            Console.WriteLine("Enter a movie name");
            movieName = Console.ReadLine();
            Console.WriteLine("Enter the actors/actress name");
            star = Console.ReadLine();
        }
        public override void Display()
        {
            Console.WriteLine(movieName);
            Console.WriteLine(star);
        }

    }
    class Bollywood : Sandalwood
    {
        Bollywood()
        {
            Console.WriteLine("hello");
        }
        public override void Review()
        {
            Console.WriteLine("Please describe the movie in a word");
            Console.WriteLine(Console.ReadLine());
        }
        public override void Accept()
        {
            Console.WriteLine("Enter a movie name");
            movieName = Console.ReadLine();
            Console.WriteLine("Enter the actors/actress name");
            star = Console.ReadLine();
        }
        public override void Display()
        {
            Console.WriteLine(movieName);
            Console.WriteLine(star);
        }
    }     
}
