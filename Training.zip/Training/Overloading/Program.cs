﻿//1. Overloading

using System;

namespace Overloading
{
    public class MainClass
    {
        public static void Main()
        {
            OverloadingClass refOverloadingClass = new OverloadingClass();
            while (true)
            {
                Console.WriteLine("Enter \n 1 to add two integer numbers \n 2 to add three integer numbers\n 3 to add two float numbers \n 4 to add three float numbers \n 5 to add two double numbers \n 6 to add three float numbers");
                int choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter the two numbers");
                        int a = Convert.ToInt32(Console.ReadLine());
                        int b = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("The sum is :" + refOverloadingClass.OverloadingMethod(a, b));
                        break;
                    case 2:
                        Console.WriteLine("Enter the three numbers");
                        int x = Convert.ToInt32(Console.ReadLine());
                        int y = Convert.ToInt32(Console.ReadLine());
                        int z = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("The sum is :" + refOverloadingClass.OverloadingMethod(x, y, z));
                        break;
                    case 3:
                        Console.WriteLine("Enter the two numbers");
                        float m = float.Parse((Console.ReadLine()));
                        float n = float.Parse((Console.ReadLine()));
                        Console.WriteLine("The sum is :" + refOverloadingClass.OverloadingMethod(m, n));
                        break;
                    case 4:
                        Console.WriteLine("Enter the three numbers");
                        float p = float.Parse((Console.ReadLine()));
                        float q = float.Parse((Console.ReadLine()));
                        float r = float.Parse((Console.ReadLine()));
                        Console.WriteLine("The sum is :" + refOverloadingClass.OverloadingMethod(p, q, r));
                        break;
                    case 5:
                        Console.WriteLine("Enter the two numbers");
                        double c = Convert.ToDouble(Console.ReadLine());
                        double d = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("The sum is :" + refOverloadingClass.OverloadingMethod(c, d));
                        break;
                    case 6:
                        Console.WriteLine("Enter the three numbers");
                        double l = Convert.ToDouble(Console.ReadLine());
                        double k = Convert.ToDouble(Console.ReadLine());
                        double v = Convert.ToDouble(Console.ReadLine());
                        Console.WriteLine("The sum is :" + refOverloadingClass.OverloadingMethod(l, k, v));
                        break;
                    default:
                        Console.WriteLine("Default case");
                        break;
                }

            }
        }
    }

    public class OverloadingClass
    {
        //int sum = 0;
        public int OverloadingMethod(int a, int b)
        {
            a += b;
            return a;
        }
        public int OverloadingMethod(int a, int b, int c)
        {
            a = a + b + c;
            return a;
        }
        public float OverloadingMethod(float a, float b)
        {
            a += b;
            return a;
        }
        public float OverloadingMethod(float a, float b, float c)
        {
            a = a + b + c;
            return a;
        }
        public double OverloadingMethod(double a, double b)
        {
            a += b;
            return a;
        }
        public double OverloadingMethod(double a, double b, double c)
        {
            a = a + b + c;
            return a;
        }
    }
}



/* 
OUTPUT



Enter 
 1 to add two integer numbers 
 2 to add three integer numbers
 3 to add two float numbers 
 4 to add three float numbers 
 5 to add two double numbers 
 6 to add three float numbers
1
Enter the two numbers
213
324
The sum is :537
Enter 
 1 to add two integer numbers 
 2 to add three integer numbers
 3 to add two float numbers 
 4 to add three float numbers 
 5 to add two double numbers 
 6 to add three float numbers
4
Enter the three numbers
1234.45
124.54
1234.754
The sum is :2593.744
Enter 
 1 to add two integer numbers 
 2 to add three integer numbers
 3 to add two float numbers 
 4 to add three float numbers 
 5 to add two double numbers 
 6 to add three float numbers
5
Enter the two numbers
354.7
235.76
The sum is :590.46
Enter 
 1 to add two integer numbers 
 2 to add three integer numbers
 3 to add two float numbers 
 4 to add three float numbers 
 5 to add two double numbers 
 6 to add three float numbers
[ConsoleInputLine_10]
Default case          
*/