﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoIdxr
{
    class Overidx
    {
        public int arrsize = 5;
        public string[] cart = new string[5];
        public string this[int index]
        {
            get
            {
                string item;
                if (index >= 0 && index <= arrsize - 1)
                {
                    item = cart[index];
                }
                else
                {
                    item = "NA";
                }
                return item;
            }

            set
            {
                if (index >= 0 && index <= arrsize - 1)
                {
                    cart[index] = value;
                }
            }
        }
        public int this[string name]
        {
            get
            {
                int index = 0;
                while (index < arrsize)
                {
                    if (cart[index] == name)
                    {
                        return index;
                    }
                    index++;
                }
                return index;
            }
        }
    }
}
