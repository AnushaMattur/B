﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoIdxr;

namespace Indxr
{
    class OverIndex
    { 
        public static void Main(string[] args)
        {

            Wardrobe wd = new Wardrobe();
            wd[0] = "Pants";
            wd[1] = "Kurti";
            wd[2] = "Shirts";
            wd[3] = "Frocks";
            wd[4] = "Gowns";

            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine(wd[i]);
            }


            Overidx idx = new Overidx();
            idx[0] = "Potatoes";
            idx[1] = "Carrots";
            idx[2] = "Turnips";

            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine(idx[i]);
            }

            Console.WriteLine("Carrots are here..");
            Console.WriteLine("Carrots are at: " + idx["Carrots"]);
        }
    }

    class Wardrobe
    {
        public int size = 5;
        public string[] dresses = new string[5];

        public string this[int index]
        {
            get
            {
                return dresses[index];
            }
            set
            {
                dresses[index] = value;
            }
        }
    }
}
