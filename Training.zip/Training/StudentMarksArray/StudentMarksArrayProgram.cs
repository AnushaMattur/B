﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentArray
{
    class Student
    {
        public int SNo { get; set; }
        public string Name { get; set; }
        public int Math { get; set; }
        public int Phy { get; set; }
        public int Chem { get; set; }
        public int Eng { get; set; }
        public int IP { get; set; }
        public int Aggr { get; set; }
    }
    class Program
    {
        static void Main()
        {
            List<Student> lstStudents = new List<Student>();
            Console.WriteLine("------------------------------------------------");
            Console.WriteLine("Enter the total number of Students");
            try
            {
                int num = int.Parse(Console.ReadLine());

                Student objStudent = new Student();
                for (int i = 0; i < num; i++)

                {
                    Console.WriteLine("------------------------------------------------");
                    Console.Write("Enter Student name               : ");
                    objStudent.SNo = i + 1;
                    objStudent.Name = Console.ReadLine();
                    Console.Write("Enter Maths Marks out of 100     : ");
                    objStudent.Math = int.Parse(Console.ReadLine());
                    Console.Write("Enter Physics Marks out of 100   : ");
                    objStudent.Phy = int.Parse(Console.ReadLine());
                    Console.Write("Enter Chemistry Marks out of 100 : ");
                    objStudent.Chem = int.Parse(Console.ReadLine());
                    Console.Write("Enter English Marks out of 100   : ");
                    objStudent.IP = int.Parse(Console.ReadLine());
                    Console.Write("Enter IP Marks out of 100        : ");
                    objStudent.Eng = int.Parse(Console.ReadLine());

                    objStudent.Aggr = (objStudent.Math + objStudent.Chem + objStudent.IP + objStudent.Eng + objStudent.Phy) / 5;
                    lstStudents.Add(objStudent);
                    objStudent = new Student();
                }
            }
            catch (FormatException e)
            {
                Console.WriteLine(e.Message + "Please Enter Correctly");
                Main();
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine(e.Message + "Please Enter Correctly");
                Main();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Main();
            }
            Console.Clear();
            Console.WriteLine("***********************************************************************************");
            Console.WriteLine("S.No    Student Name       Maths      Phy      Chem      Eng       IP     Aggregate");
            Console.WriteLine("***********************************************************************************");

            //Looping through the list of students
            foreach (Student currentSt in lstStudents)
            {
                //no need to type cast since compiler already knows that everything inside 
                //this list is a Student

                Console.WriteLine("{0,-8}{1,-20}{2,-10}{3,-10}{4,-10}{5,-10}{6,-10}{7,-10}", currentSt.SNo, currentSt.Name, currentSt.Math, currentSt.Phy, currentSt.Eng, currentSt.IP, currentSt.Chem, currentSt.Aggr);
            }
            Console.WriteLine("***********************************************************************************");
            Console.ReadKey();
        }
    }
}